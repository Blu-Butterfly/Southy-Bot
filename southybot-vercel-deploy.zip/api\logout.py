from http.server import BaseHTTPRequestHandler

from _southybot import handle_options, send_json


class handler(BaseHTTPRequestHandler):
    def do_OPTIONS(self):
        handle_options(self)

    def do_POST(self):
        send_json(self, {"ok": True})
