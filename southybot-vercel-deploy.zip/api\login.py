from http.server import BaseHTTPRequestHandler

from _southybot import (
    create_session_token,
    find_user,
    handle_options,
    read_json_body,
    send_json,
    verify_password,
)


class handler(BaseHTTPRequestHandler):
    def do_OPTIONS(self):
        handle_options(self)

    def do_POST(self):
        try:
            payload = read_json_body(self)
            role = str(payload.get("role", "")).strip().lower()
            username = str(payload.get("username", "")).strip().lower()
            password = str(payload.get("password", ""))

            if not role or not username or not password:
                send_json(self, {"ok": False, "error": "Role, username, and password are required."}, status=400)
                return

            user = find_user(role, username)

            if not user or not verify_password(password, user):
                send_json(self, {"ok": False, "error": "Invalid login details."}, status=401)
                return

            token, session = create_session_token(user)
            send_json(
                self,
                {
                    "ok": True,
                    "token": token,
                    "expiresAt": session["expiresAt"],
                    "user": session["user"],
                },
            )
        except Exception as error:
            send_json(self, {"ok": False, "error": str(error)}, status=500)
