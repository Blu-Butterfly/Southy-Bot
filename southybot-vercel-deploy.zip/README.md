# SouthyBot Deployment Package

This folder contains the Southwestern University frontend, SouthyBot chat UI, login API, and deployable backend.

## Run Locally

```powershell
python .\server.py
```

Open:

```text
http://127.0.0.1:4173/
```

Local mode automatically reads the Access database when it is available:

```text
C:\Users\Esther Oladega\Documents\SouthyBot KnowledgeBase.accdb
```

## Cloud Deployment

Cloud hosts usually cannot read Microsoft Access files, so this package includes `api/data/knowledge-base.json` with the exported bot data.

## Vercel Deployment

Deploy this folder as the project root:

```text
outputs/southwestern-frontend
```

Vercel will serve the website files and use the Python serverless functions in `api/`.

Recommended Vercel settings:

```text
Framework Preset: Other
Build Command: leave empty
Output Directory: leave empty
Install Command: leave empty
```

Add this environment variable:

```text
SOUTHYBOT_SESSION_SECRET=choose-a-long-random-secret
```

After deployment, test:

```text
https://your-project.vercel.app/
https://your-project.vercel.app/api/health
```

## Render Deployment

Use these settings on a Python web service host:

```text
Build command: pip install -r requirements.txt
Start command: python server.py
Environment variable: SOUTHYBOT_KB_SOURCE=json
```

The server also supports the standard cloud `PORT` environment variable.

## Included Deployment Files

- `index.html` - main website page
- `login.html` - login page
- `styles.css` - website styling
- `script.js` - SouthyBot and login frontend logic
- `server.py` - Python web server and API
- `api/data/knowledge-base.json` - deployable SouthyBot data export
- `api/data/auth-users.json` - demo login users
- `api/*.py` - Vercel serverless API functions
- `vercel.json` - Vercel configuration
- `.python-version` - Python runtime version for Vercel
- `Procfile` - process file for Heroku-style hosts
- `render.yaml` - Render blueprint
- `requirements.txt` - Python dependency file

## Demo Login Accounts

```text
Student: student / student123
Applicant: applicant / applicant123
Staff: staff / staff123
```
