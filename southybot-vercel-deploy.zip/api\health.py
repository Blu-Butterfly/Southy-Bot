from http.server import BaseHTTPRequestHandler

from _southybot import KNOWLEDGE_BASE_PATH, handle_options, send_json


class handler(BaseHTTPRequestHandler):
    def do_OPTIONS(self):
        handle_options(self)

    def do_GET(self):
        send_json(
            self,
            {
                "ok": KNOWLEDGE_BASE_PATH.exists(),
                "sourceMode": "json",
                "jsonPath": str(KNOWLEDGE_BASE_PATH),
            },
        )
