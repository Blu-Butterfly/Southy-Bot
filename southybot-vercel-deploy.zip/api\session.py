from http.server import BaseHTTPRequestHandler

from _southybot import bearer_token, decode_session_token, handle_options, send_json


class handler(BaseHTTPRequestHandler):
    def do_OPTIONS(self):
        handle_options(self)

    def do_GET(self):
        session = decode_session_token(bearer_token(self))

        if not session:
            send_json(self, {"ok": False, "error": "No active session."}, status=401)
            return

        send_json(self, {"ok": True, **session})
