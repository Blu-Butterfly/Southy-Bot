from http.server import BaseHTTPRequestHandler
from time import time

from _southybot import handle_options, load_knowledge_records, send_json


class handler(BaseHTTPRequestHandler):
    def do_OPTIONS(self):
        handle_options(self)

    def do_GET(self):
        started_at = time()

        try:
            records = load_knowledge_records()
            send_json(
                self,
                {
                    "ok": True,
                    "source": "json",
                    "recordCount": len(records),
                    "durationMs": round((time() - started_at) * 1000),
                    "records": records,
                },
            )
        except Exception as error:
            send_json(self, {"ok": False, "error": str(error), "records": []}, status=500)
