from __future__ import annotations

from datetime import datetime, timedelta, timezone
from pathlib import Path
from urllib.parse import parse_qs, urlparse
import base64
import hashlib
import hmac
import json
import os
import secrets


ROOT = Path(__file__).resolve().parent
PROJECT_ROOT = ROOT.parent
KNOWLEDGE_BASE_PATH = Path(os.environ.get("SOUTHYBOT_KB_JSON", ROOT / "data" / "knowledge-base.json"))
AUTH_USERS_PATH = Path(os.environ.get("SOUTHYBOT_AUTH_USERS", ROOT / "data" / "auth-users.json"))
PASSWORD_ITERATIONS = 120000
SESSION_SECRET = os.environ.get("SOUTHYBOT_SESSION_SECRET", "southybot-demo-session-secret")


def load_knowledge_records():
    payload = json.loads(KNOWLEDGE_BASE_PATH.read_text(encoding="utf-8-sig"))

    if isinstance(payload, dict):
        payload = payload.get("records", [])

    if not isinstance(payload, list):
        raise ValueError("SouthyBot data must be a list of records.")

    return payload


def load_auth_users():
    return json.loads(AUTH_USERS_PATH.read_text(encoding="utf-8-sig"))


def find_user(role, username):
    normalized_role = str(role or "").strip().lower()
    normalized_username = str(username or "").strip().lower()

    for user in load_auth_users():
        aliases = {
            str(user.get("username", "")).lower(),
            str(user.get("email", "")).lower(),
            *[str(alias).lower() for alias in user.get("aliases", [])],
        }

        if str(user.get("role", "")).lower() == normalized_role and normalized_username in aliases:
            return user

    return None


def verify_password(password, user):
    salt = str(user.get("salt", "")).encode("utf-8")
    expected_hash = str(user.get("passwordHash", ""))
    actual_hash = hashlib.pbkdf2_hmac(
        "sha256",
        str(password or "").encode("utf-8"),
        salt,
        PASSWORD_ITERATIONS,
    ).hex()
    return hmac.compare_digest(actual_hash, expected_hash)


def public_user(user):
    return {
        "id": user.get("id"),
        "role": user.get("role"),
        "username": user.get("username"),
        "email": user.get("email"),
        "displayName": user.get("displayName"),
    }


def create_session_token(user):
    expires_at = datetime.now(timezone.utc) + timedelta(hours=8)
    payload = {
        "user": public_user(user),
        "expiresAt": expires_at.isoformat(),
        "nonce": secrets.token_urlsafe(12),
    }
    payload_json = json.dumps(payload, separators=(",", ":"), sort_keys=True).encode("utf-8")
    payload_part = base64.urlsafe_b64encode(payload_json).decode("ascii").rstrip("=")
    signature = hmac.new(SESSION_SECRET.encode("utf-8"), payload_part.encode("ascii"), hashlib.sha256).digest()
    signature_part = base64.urlsafe_b64encode(signature).decode("ascii").rstrip("=")
    return f"{payload_part}.{signature_part}", payload


def decode_session_token(token):
    if not token or "." not in token:
        return None

    payload_part, signature_part = token.split(".", 1)
    expected_signature = hmac.new(
        SESSION_SECRET.encode("utf-8"),
        payload_part.encode("ascii"),
        hashlib.sha256,
    ).digest()
    actual_signature = base64.urlsafe_b64decode(pad_base64(signature_part))

    if not hmac.compare_digest(actual_signature, expected_signature):
        return None

    payload = json.loads(base64.urlsafe_b64decode(pad_base64(payload_part)).decode("utf-8"))
    expires_at = datetime.fromisoformat(payload["expiresAt"])

    if expires_at <= datetime.now(timezone.utc):
        return None

    return payload


def pad_base64(value):
    return value + "=" * (-len(value) % 4)


def read_json_body(handler):
    content_length = int(handler.headers.get("Content-Length", 0))

    if content_length <= 0:
        return {}

    raw_body = handler.rfile.read(content_length).decode("utf-8")
    return json.loads(raw_body or "{}")


def bearer_token(handler):
    authorization = handler.headers.get("Authorization", "")

    if authorization.lower().startswith("bearer "):
        return authorization[7:].strip()

    return ""


def send_json(handler, payload, status=200):
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    handler.send_response(status)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Content-Length", str(len(body)))
    handler.send_header("Access-Control-Allow-Origin", "*")
    handler.send_header("Access-Control-Allow-Headers", "Authorization, Content-Type")
    handler.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
    handler.end_headers()
    handler.wfile.write(body)


def handle_options(handler):
    handler.send_response(204)
    handler.send_header("Access-Control-Allow-Origin", "*")
    handler.send_header("Access-Control-Allow-Headers", "Authorization, Content-Type")
    handler.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
    handler.end_headers()


def query_params(handler):
    return parse_qs(urlparse(handler.path).query)
